﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Praktika27.Classes;

namespace Praktika27.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddAuthor.xaml
    /// </summary>
    public partial class PageAddAuthor : Page
    {
        private Author _currentAuthor = new Author();
        public PageAddAuthor(Author selectedAuthor)
        {
            InitializeComponent();
            if (selectedAuthor != null)
            {
                _currentAuthor = selectedAuthor;
                TxtName.Text = "Изменение автора";
                BtnAddAuthor.Content = "Изменить";
            }
            DataContext = _currentAuthor;
        }

        private void BtnAddAuthor_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentAuthor.FIO)) error.AppendLine("Укажите ФИО автора");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentAuthor.idAuthor == 0)
            {
                HomeLibraryEntities.GetContext().Author.Add(_currentAuthor);
                try
                {
                    HomeLibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frbObj.Navigate(new PageAuthor());
                    MessageBox.Show("Новый автор успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    HomeLibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frbObj.Navigate(new PageAuthor());
                    MessageBox.Show("Автор успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelAuthor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAuthor());
        }
    }
}
