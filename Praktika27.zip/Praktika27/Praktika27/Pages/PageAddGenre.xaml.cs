﻿using Praktika27.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Praktika27.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddGenre.xaml
    /// </summary>
    public partial class PageAddGenre : Page
    {
        private Genre _currentGenre = new Genre();
        public PageAddGenre(Genre selectedGenre)
        {
            InitializeComponent();
            if (selectedGenre != null)
            {
                _currentGenre = selectedGenre;
                Txttitle.Text = "Изменение жанра";
                BtnAddGenre.Content = "Изменить";
            }
            DataContext = _currentGenre;
        }

        private void BtnAddGenre_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentGenre.title)) error.AppendLine("Укажите название жанра");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentGenre.idGenre == 0)
            {
                HomeLibraryEntities.GetContext().Genre.Add(_currentGenre);
                try
                {
                    HomeLibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frbObj.Navigate(new PageGenre());
                    MessageBox.Show("Новый жанр успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    HomeLibraryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frbObj.Navigate(new PageGenre());
                    MessageBox.Show("Жанр успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelGenre_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageGenre());
        }
    }
}
