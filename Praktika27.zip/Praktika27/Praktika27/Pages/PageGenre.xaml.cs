﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Praktika27.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Praktika27.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageGenre.xaml
    /// </summary>
    public partial class PageGenre : Page
    {
        public PageGenre()
        {
            InitializeComponent();
            DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.ToList();
        }


        private void MenuAddGenre_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAddGenre(null));
        }

        private void MenuEditGenre_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAddGenre((Genre)DtgGenre.SelectedItem));
        }

        private void MenuExportToExcelGenre_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[2][2] = "Жанр";
            ws.Cells[4, 3] = DateTime.Now.ToString("dd/MM/yyyy");
            ws.Cells[4, 6] = 8;
            int indexRows = 6;
            ws.Cells[2][indexRows] = "Номер";
            ws.Cells[3][indexRows] = "Название жанра";
            var printItems = DtgGenre.Items;
            foreach (Genre item in printItems)
            {
                ws.Cells[2][indexRows + 1] = indexRows;
                ws.Cells[3][indexRows + 1] = item.title;
                indexRows++;
            }
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Пилипенко Б.А.";
            excelApp.Visible = true;
        }

        private void MenuSortDescGenre_Click(object sender, RoutedEventArgs e)
        {
            DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.OrderBy(x => x.title).ToList();
        }

        private void MenuSortDescGenre1_Click(object sender, RoutedEventArgs e)
        {
            DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.OrderByDescending(x => x.title).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.ToList();
        }



        private void MenuDelGenre_Click(object sender, RoutedEventArgs e)
        {
            var productForRemoving = DtgGenre.SelectedItems.Cast<Genre>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {productForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    HomeLibraryEntities.GetContext().Genre.RemoveRange(productForRemoving);
                    HomeLibraryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchGenre_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgGenre.ItemsSource != null)
            {
                DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.Where(x => x.title.ToLower().Contains(SearchGenre.Text.ToLower())).ToList();
            }
            if (SearchGenre.Text.Count() == 0) DtgGenre.ItemsSource = HomeLibraryEntities.GetContext().Genre.ToList();
        }
    }
    }
