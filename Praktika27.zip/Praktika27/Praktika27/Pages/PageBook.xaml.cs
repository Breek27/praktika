﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Praktika27.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Praktika27.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageBook.xaml
    /// </summary>
    public partial class PageBook : Page
    {
        public PageBook()
        {
            InitializeComponent();
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.ToList();
        }

        private void MenuAddBook_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAddBook(null));
        }

        private void MenuEditBook_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAddBook((Book)DtgBook.SelectedItem));
        }

        private void MenuExportToExcelBook_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[2][2] = "Книги";
            ws.Cells[4, 3] = DateTime.Now.ToString("dd/MM/yyyy");
            ws.Cells[4, 6] = 6;
            int indexRows = 6;
            ws.Cells[2][indexRows] = "Номер";
            ws.Cells[3][indexRows] = "Название";
            ws.Cells[4][indexRows] = "Кол-во стр.";
            ws.Cells[5][indexRows] = "Издательство";
            ws.Cells[6][indexRows] = "Автор";
            ws.Cells[3][indexRows] = "Жанр";
            var printItems = DtgBook.Items;
            foreach (Book item in printItems)
            {
                ws.Cells[2][indexRows + 1] = indexRows;
                ws.Cells[3][indexRows + 1] = item.title;
                ws.Cells[4][indexRows + 1] = item.countpages;
                ws.Cells[5][indexRows + 1] = item.publishing;
                ws.Cells[6][indexRows + 1] = item.Author.FIO;
                ws.Cells[7][indexRows + 1] = item.Genre.title;
                indexRows++;
            }
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Пилипенко Б.А.";
            excelApp.Visible = true;
        }

        private void MenuSortDescBook_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.OrderBy(x => x.title).ToList();
        }

        private void MenuSortDescBook1_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.OrderByDescending(x => x.title).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.ToList();
        }

        private void MenuFilterBook_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.Where(x => x.countpages <= 110).ToList();
        }

        private void MenuFilterBook2_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.Where(x => x.countpages>= 111 && x.countpages <= 399).ToList();
        }

        private void MenuFilterBook3_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.Where(x => x.countpages >= 400).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.ToList();
        }

        private void MenuDelBook_Click(object sender, RoutedEventArgs e)
        {
            var bookForRemoving = DtgBook.SelectedItems.Cast<Book>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {bookForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    HomeLibraryEntities.GetContext().Book.RemoveRange(bookForRemoving);
                    HomeLibraryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchBook_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgBook.ItemsSource != null)
            {
                DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.Where(x => x.Genre.title.ToLower().Contains(SearchBook.Text.ToLower())).ToList();
            }
            if (SearchBook.Text.Count() == 0) DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.ToList();
        }

        private void SearchAuthor_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgBook.ItemsSource != null)
            {
                DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.Where(x => x.Author.FIO.ToLower().Contains(SearchAuthor.Text.ToLower())).ToList();
            }
            if (SearchAuthor.Text.Count() == 0) DtgBook.ItemsSource = HomeLibraryEntities.GetContext().Book.ToList();
        }
    }
    }

