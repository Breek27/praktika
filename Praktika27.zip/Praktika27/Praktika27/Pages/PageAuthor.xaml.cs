﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Praktika27.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace Praktika27.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAuthor.xaml
    /// </summary>
    public partial class PageAuthor : Page
    {
        public PageAuthor()
        {
            InitializeComponent();
            DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.ToList();
        }


        private void MenuAddAuthor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAddAuthor(null));
        }

        private void MenuEditAuthor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frbObj.Navigate(new PageAddAuthor((Author)DtgAuthor.SelectedItem));
        }

        private void MenuExportToExcelAuthor_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[2][2] = "Книги";
            ws.Cells[4, 3] = DateTime.Now.ToString("dd/MM/yyyy");
            ws.Cells[4, 6] = 7;
            int indexRows = 6;
            ws.Cells[2][indexRows] = "Номер";
            ws.Cells[3][indexRows] = "ФИО";
            var printItems = DtgAuthor.Items;
            foreach (Author item in printItems)
            {
                ws.Cells[2][indexRows + 1] = indexRows;
                ws.Cells[3][indexRows + 1] = item.FIO;
                indexRows++;
            }
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Пилипенко Б.А.";
            excelApp.Visible = true;
        }

        private void MenuSortDescAuthor_Click(object sender, RoutedEventArgs e)
        {
            DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.OrderBy(x => x.FIO).ToList();
        }

        private void MenuSortDescAuthor1_Click(object sender, RoutedEventArgs e)
        {
            DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.OrderByDescending(x => x.FIO).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.ToList();
        }

        private void MenuDelAuthor_Click(object sender, RoutedEventArgs e)
        {
            var AuthorForRemoving = DtgAuthor.SelectedItems.Cast<Author>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {AuthorForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    HomeLibraryEntities.GetContext().Author.RemoveRange(AuthorForRemoving);
                    HomeLibraryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchAuthor_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgAuthor.ItemsSource != null)
            {
                DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.Where(x => x.FIO.ToLower().Contains(SearchAuthor.Text.ToLower())).ToList();
            }
            if (SearchAuthor.Text.Count() == 0) DtgAuthor.ItemsSource = HomeLibraryEntities.GetContext().Author.ToList();
        }
    }
 }

